self.assetsManifest = {
  "version": "j7zXgCJh",
  "assets": [
    {
      "hash": "sha256-KSqoMKAxkVF51fZPjtetXhWPpd26S82yAU1Lerq2tus=",
      "url": "Js/animations.js"
    },
    {
      "hash": "sha256-i5m69T1OPEimDzx0PcIUlnVgaZM9jDAtEkBRk5QHmpc=",
      "url": "Js/experienceAnimations.js"
    },
    {
      "hash": "sha256-EyDpkd7d+xalVBWeiGnb/RyXv3FOOf0Vb1KmJdi+EPU=",
      "url": "Js/projectsAnimations.js"
    },
    {
      "hash": "sha256-m8ViDUKt19hkqVEFB79nz7LN4/VjmHpwFWzMGa/VRTM=",
      "url": "Js/skillsAnimations.js"
    },
    {
      "hash": "sha256-WAk4NT90NrBx7eRmLD3tJAavDmLW+Ptmz7gzeFiq8cg=",
      "url": "Pics/Companies/cydista-logo.png"
    },
    {
      "hash": "sha256-lZbid0z6CGstqPZ1GMHjgHyVCLPh94NLqAQQZ2ymR6w=",
      "url": "Pics/Companies/dev-newtech-logo.png"
    },
    {
      "hash": "sha256-R8uE3k40/hs56HD8FIm9ke/+fa6P4X/Tw2+QA3JF8b8=",
      "url": "Pics/Companies/neoconcept-logo.png"
    },
    {
      "hash": "sha256-89O1Rm2u8rxX+T+Jaoe53Qt2OYkmBCAxtngDTliHvwk=",
      "url": "Pics/Projects/blazordynamicforms-logo.png"
    },
    {
      "hash": "sha256-ussTzgk9tRJI95IPl1jzXLiL0Wi9Tq7jnnk3dlc057Y=",
      "url": "Pics/Projects/deepquiz-logo.png"
    },
    {
      "hash": "sha256-bDIwIgyTW1ux2OYFuZ8c7QO0upUYqcVKRMQo7igoT9Y=",
      "url": "Pics/Projects/maison-apple-logo.png"
    },
    {
      "hash": "sha256-ADlccaYLsmAX7r2tCGyh2Pu3OHSzFS7GOM2/KlQ+Zl8=",
      "url": "Pics/Projects/penlyzard-logo.png"
    },
    {
      "hash": "sha256-KjtQpYF0PvgoHLpL78MrXcwWkCijLQ4xAu4r++ooXEc=",
      "url": "Pics/pfp.png.jpeg"
    },
    {
      "hash": "sha256-mF0E5es8a5EyHbI1z4L6U5Cjk2t71Iz9GM6Q5JQQrls=",
      "url": "Portfolio.WASM.styles.css"
    },
    {
      "hash": "sha256-kAomisQNMm5PzhfCHSlzVxk083RuuRQ3D0JnBdKptJg=",
      "url": "_framework/Microsoft.AspNetCore.Components.43yo8wssuk.wasm"
    },
    {
      "hash": "sha256-c+eu6ab1NEaXaMfP/oMRFx2dn1EylIQ5qd6Slq48IWM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.p93gsis3o8.wasm"
    },
    {
      "hash": "sha256-D/ZUWrvE7bqOtBfOWuLj+4RNqOvNZ0SnjD6QrBwUcb8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.pq7fdyw1tb.wasm"
    },
    {
      "hash": "sha256-AyL87FvJMf14Dcn8HeQ3n2veg/RQGVGCjfpJPt1RQC4=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.f9jq6u05xu.wasm"
    },
    {
      "hash": "sha256-TUkUL2Leb3zmGe8ZZUHAzyb8vZoEzua1H8f8stc7xRw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.77nptesqpn.wasm"
    },
    {
      "hash": "sha256-0iZA+rfvr3lLmK5V18g0LZCU41c3mbTL9jNYRoavdB0=",
      "url": "_framework/Microsoft.Extensions.Configuration.ell6o7ap7i.wasm"
    },
    {
      "hash": "sha256-Ba5NdPQTvHVjnFX7kh/XyQIVNwfdoGXkKHF8w2H6PU0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.p7b5uiooiy.wasm"
    },
    {
      "hash": "sha256-EPey4pvx6aL8aj8zL05ip1ZJSUG7DjjOrtL9aPRDYPw=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.g8opmrm9gr.wasm"
    },
    {
      "hash": "sha256-a881iT/kmq3LnryJklnQzsMD93/W6dM0x/3xSE38e6I=",
      "url": "_framework/Microsoft.Extensions.Logging.5g1hnmwyc5.wasm"
    },
    {
      "hash": "sha256-orBsRyrmQ2tga4R/Z9nE0NDH6jGWYutysMdSEM1i6/o=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.udb0ns9y9g.wasm"
    },
    {
      "hash": "sha256-tXQZqZqNvPMoYp2INR4AOHcvE8kWly2WAYbjvmmuiXU=",
      "url": "_framework/Microsoft.Extensions.Options.9zsgy7ya5a.wasm"
    },
    {
      "hash": "sha256-TYdWPCwhKBdHQ79Fa7lunjzdUXfcxyaR1fAk0y11/ig=",
      "url": "_framework/Microsoft.Extensions.Primitives.tcgeh3akx1.wasm"
    },
    {
      "hash": "sha256-lNqP2ot1f2PhPr/5ZgFueuYFhUgz/pVAaqmi0u4H8Lo=",
      "url": "_framework/Microsoft.JSInterop.426305nhc4.wasm"
    },
    {
      "hash": "sha256-99wG3VH14sWkwPaF5rX6YAcJvtAhDuqonwihvj2m5HA=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.heoad7mujs.wasm"
    },
    {
      "hash": "sha256-pQOBhV+HCiDmNSn2IxaNGnUs9qIw18byVQ4M3RiBKmQ=",
      "url": "_framework/Portfolio.WASM.zyfeobp4bn.wasm"
    },
    {
      "hash": "sha256-kXfPmJ6+TbQAP0UxmlBgT5ZlcP4SXorTEqTiozxW+18=",
      "url": "_framework/System.Collections.Concurrent.dpcpjq5awi.wasm"
    },
    {
      "hash": "sha256-i+DxbIWVv8PjrVUuy6SdxGBhmy90ieSrlG21KC61fk0=",
      "url": "_framework/System.Collections.Immutable.tmw1g9f0td.wasm"
    },
    {
      "hash": "sha256-crD2DP8dTb9gOby3Wxa1BrSOXz03qKOZWI0WuMnkz9c=",
      "url": "_framework/System.Collections.exwvgq8nho.wasm"
    },
    {
      "hash": "sha256-WyPLE0inD0/vY79fvGY+k+jDku6WEB8WJruWIMhiBXM=",
      "url": "_framework/System.ComponentModel.hd4i21d5zf.wasm"
    },
    {
      "hash": "sha256-ikqTNMM4nCzTvy0vq+eyrfJQJQsIKdPkd6r2Wj+W9CI=",
      "url": "_framework/System.Console.e26jkbjtyb.wasm"
    },
    {
      "hash": "sha256-d4Fv2UP7j+pqOrhljw06Xjdf1UB0VVgcWQAZYM+e2Ak=",
      "url": "_framework/System.IO.Pipelines.3p3f5vckx6.wasm"
    },
    {
      "hash": "sha256-lV2rLKp5/JNk1gpThEpuyCHlzSBnrZsM/L4fnN9Mj0M=",
      "url": "_framework/System.Linq.5kwvrzgh9k.wasm"
    },
    {
      "hash": "sha256-T4V4WK4ivondTGxxmpFrh6FtW5g8YISuktRz5K9Bp1E=",
      "url": "_framework/System.Memory.ddx3v4m9gx.wasm"
    },
    {
      "hash": "sha256-4QI1wOCtQSq/83+bNlWTBmCg1wggLcCDsXLIzGRPAJA=",
      "url": "_framework/System.Net.Http.jvborohthi.wasm"
    },
    {
      "hash": "sha256-KH4CVAPEDPjgX5PXvYBbhlTzNNL/Own3ELMwYvJ+tzM=",
      "url": "_framework/System.Net.Primitives.kdvc0a7ikr.wasm"
    },
    {
      "hash": "sha256-KHYCyeJ/+op36Cf6070BqAnGzV+/3YvolAMf9esA8LE=",
      "url": "_framework/System.Private.CoreLib.osaecjpcrf.wasm"
    },
    {
      "hash": "sha256-3YefOmWC2eidgkKSeVGau5E6HH5qFZpz26UDn75oBAw=",
      "url": "_framework/System.Private.Uri.jwtff51u5g.wasm"
    },
    {
      "hash": "sha256-pLr/Ys4hCRUIbnJOTabUttdOQTgaKzJPRmT6/do1uGg=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.83zwdhfd7p.wasm"
    },
    {
      "hash": "sha256-Jy34vSH/Zsth3p98qMWi6Kv4CiMLaLArnn5FUmr4XvA=",
      "url": "_framework/System.Runtime.bb1untg7ck.wasm"
    },
    {
      "hash": "sha256-9FZLttu5iPwF9M7jckzJNogrhKhsHb9VlRtzW9+OH44=",
      "url": "_framework/System.Text.Encodings.Web.suy6578t21.wasm"
    },
    {
      "hash": "sha256-sXuIXXV6GDrgOHS7hgPVUT0qP7QuwAvYcUwGzYyxrY0=",
      "url": "_framework/System.Text.Json.jjhatov2mh.wasm"
    },
    {
      "hash": "sha256-dAw+dIKra7ljgRE+eVWL5wTVKKXPJi7x/AdHfLLcFDs=",
      "url": "_framework/System.Text.RegularExpressions.k0eu65ve7y.wasm"
    },
    {
      "hash": "sha256-M8LmCODWnX6CMsl7eXrVx/2rkLT7DccjvZg8tQf9vjE=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-lh8bY3DINgTiqGL/cwOeVaJGdfE2ex1o8MzwCbmlZZE=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-0C5th70x3cgwI6otbYfnZFNKiDFUEWeeGoJEdszlFRc=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-HHqsNtcX76Ik012KVAobmCLooIZ2znhTFCqfijzEdi0=",
      "url": "_framework/dotnet.native.swgexbmoy7.wasm"
    },
    {
      "hash": "sha256-/ifJokfQvXKw1hEziCkYR9SOJIKSdGG/UKw5gbLWrj0=",
      "url": "_framework/dotnet.native.uhsveqo9bs.js"
    },
    {
      "hash": "sha256-kTZbe5ESp04VMT22TnjRmFj88VbtEcohZfCm4og/IDw=",
      "url": "_framework/dotnet.runtime.5nhp1wfg9b.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-l14XCCnqx7i8us2qByJBx2UOvtfy3i8KKyLKM8ptwdk=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-2p/NK0Qf4Dg7XEJANCEZcaZ5kX24RB+Qy340jcYy/Yw=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-V5mdQuk/5qb3NKMzKCQX9iA3ttjDdRxpspJB1QesZ0I=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-JTRyQ22QvNydsK/d6uNiIeVLTBPL+LBJD9OkO2B2SXU=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-U2jLdbZqf3IpQ/XpVg7uHG1ujJGzwwm6UAOte8ta/zk=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-XX490I+nZlJ0eXBebrRYgfMbTZwAjNNK87BJOBtpV7E=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-j+hS/ur2zrlqNK5FAdtJDJcts+RBk+I3sMVLk+MVtYo=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-j18b6BDXPThJptwRGqUwUkl2rnlAH7ahNztzXqKjHqs=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-9G8R0te4jWbX1AExGATq2QbyjCZA3O7ramIJ2JQRlfM=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-kZZmT+ciu9n/l9YshhcZOsdjGFez7rKTF6fpq6q2KdY=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-70O/Vtp2oVQ3yGXZUh0DzM3kV5PX4k729CsBaGXR0m0=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-jbQfuzz/y60ChIkHU9jUIvbryeG1MSKFRy+7J1QZ4ys=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-paIeuWnSzjeLGITWkk4p3rcejUsZWCJGPeOK9UhWXtg=",
      "url": "sample-data/weather.json"
    }
  ]
};
